# this is a shell script

# comments begin with #

# this script doesn't actually do anything, since I listened
# to Prof. Sherr's advice and used Python, and Python doesn't require
# compilation.  So let's just exit.

exit 0

# but since I'm not a jerk, here's an example of what it might look
# like if I did my assignment in C.  (In which case I'd remove the lines
# above this, since I don't want my shell script to exit (see line 9).)

gcc -Wall -g hw1.c -o hw1
